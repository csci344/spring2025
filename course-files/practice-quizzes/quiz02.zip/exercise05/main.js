const canvasWidth = window.innerWidth;
const canvasHeight = window.innerHeight; 
    
function setup() {
    createCanvas(canvasWidth, canvasHeight);

    // function invocations goes here:



    drawGrid(canvasWidth, canvasHeight);
}


// function definition goes here:
