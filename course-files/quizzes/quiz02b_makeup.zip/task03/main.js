// your code here:
async function search() {
    console.log();
    const term = document.querySelector("#term").value;
    const location = document.querySelector("#location").value;
    console.log(term, location);

    // complete this function by invoking your getBusinesses function,
    // iterating through the results, and adding an HTML representation
    // of each business to the DOM.
}
