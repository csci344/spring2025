fake_db = {
    "posts": [
        {
            "id": 1,
            "name": "Elmo",
            "image_url": "https://picsum.photos/id/176/300/250",
            "user_id": 4,
        },
        {
            "id": 2,
            "name": "Grover",
            "image_url": "https://picsum.photos/id/177/300/250",
            "user_id": 6,
        },
        {
            "id": 3,
            "name": "Big Bird",
            "image_url": "https://picsum.photos/id/178/300/250",
            "user_id": 8,
        },
        {
            "id": 4,
            "name": "Oscar",
            "image_url": "https://picsum.photos/id/182/300/250",
            "user_id": 5,
        },
    ],
    "users": [
        {
            "id": 4,
            "username": "anis",
            "thumb_url": "https://picsum.photos/id/182/30/30",
        },
        {
            "id": 5,
            "username": "ari",
            "thumb_url": "https://picsum.photos/id/166/30/30",
        },
        {
            "id": 6,
            "username": "ben",
            "thumb_url": "https://picsum.photos/id/157/30/30",
        },
        {
            "id": 8,
            "username": "chris",
            "thumb_url": "https://picsum.photos/id/115/30/30",
        },
        {
            "id": 9,
            "username": "dorsey",
            "thumb_url": "https://picsum.photos/id/202/30/30",
        },
        {
            "id": 11,
            "username": "given",
            "thumb_url": "https://picsum.photos/id/141/30/30",
        },
    ],
}
