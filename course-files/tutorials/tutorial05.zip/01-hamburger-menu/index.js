const menuToggle = document.getElementById("menu-toggle");
const navLinks = document.getElementById("nav-links");

function toggleMenu() {
    menuToggle.classList.toggle("active");
    navLinks.classList.toggle("active");
}

